<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterShipmentSettingsTableV1 extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $items = array(
            [
                "key"       =>  "is_def_mile_or_fees",
                "value"      =>  "2",
            ],
            [
                "key"       =>  "def_pickup_cost",
                "value"      =>  "0",
            ],
            [
                "key"       =>  "def_supply_cost",
                "value"      =>  "0",
            ],
            [
                "key"       =>  "def_mile_cost",
                "value"      =>  "0",
            ],
            [
                "key"       =>  "def_return_mile_cost",
                "value"      =>  "0",
            ],
            [
                "key"       =>  "def_mile_cost_gram",
                "value"      =>  "0",
            ],
            [
                "key"       =>  "def_return_mile_cost_gram",
                "value"      =>  "0",
            ],
            
            
            
        );
        DB::table('shipment_settings')->insert($items);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('shipment_settings', function (Blueprint $table) {
            //
        });
    }
}
