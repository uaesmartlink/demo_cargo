<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ClientShipmentLog extends Model
{
    protected $table = "client_shipment_logs";
}
